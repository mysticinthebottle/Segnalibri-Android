# Segnalibri — Android

App nativa Android in Java, senza riferimenti a Firefox o dipendenze esterne.

## Funzioni incluse
- Aggiunta e modifica dei segnalibri (nome, URL, cartella, descrizione).
- Ricerca per nome, URL, cartella e descrizione.
- Descrizioni visualizzate nelle schede dei segnalibri.
- Barra delle cartelle scorrevole orizzontalmente, adatta anche a schermi stretti.
- Cartelle e spostamento dei segnalibri.
- Apertura dei collegamenti nel browser installato.
- Condivisione di un segnalibro.
- Importazione di backup JSON con scelta tra unione (ignorando URL duplicati) e sostituzione dei dati esistenti.
- Esportazione/condivisione del backup JSON e dell'elenco testuale.
- Rimozione dei duplicati.
- Salvataggio locale sul dispositivo.

## Novità versione 1.1.0
- Barra cartelle scorrevole per evitare pulsanti compressi.
- Descrizioni visibili e incluse nella ricerca.
- Importazione JSON con validazione, unione senza duplicati o sostituzione completa.

## Compatibilità
- Android minimo: 10 (API 29).
- Target SDK: 35.
- Nessun account e nessuna sincronizzazione cloud; i dati restano sul dispositivo.

## Compilare l'APK
1. Installa Android Studio aggiornato e il JDK richiesto dalla versione di Android Gradle Plugin.
2. Estrai la cartella `Segnalibri`.
3. In Android Studio scegli **Open** e seleziona questa cartella.
4. Attendi la sincronizzazione Gradle e installa Android SDK Platform 35 se richiesto.
5. Per un APK di prova: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. L'APK di debug sarà normalmente in `app/build/outputs/apk/debug/app-debug.apk`.

Per distribuire l'app, genera un APK firmato da **Build > Generate Signed Bundle / APK**.
