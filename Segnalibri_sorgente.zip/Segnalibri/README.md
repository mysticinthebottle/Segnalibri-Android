# Segnalibri — Android

App nativa Android in Java, senza riferimenti a Firefox o dipendenze esterne.

## Funzioni incluse
- Aggiunta e modifica dei segnalibri (nome, URL, cartella, descrizione).
- Ricerca per nome, URL e cartella.
- Cartelle e spostamento dei segnalibri.
- Apertura dei collegamenti nel browser installato.
- Condivisione di un segnalibro.
- Esportazione/condivisione del backup JSON e dell'elenco testuale.
- Rimozione dei duplicati.
- Salvataggio locale sul dispositivo.

## Compatibilità
- Android minimo: 10 (API 29).
- Target SDK: 35.
- Nessun account e nessuna sincronizzazione cloud; i dati restano sul dispositivo.

## Compilare l'APK
1. Installa Android Studio aggiornato e il JDK richiesto dalla versione di Android Gradle Plugin.
2. Estrai la cartella `Segnalibri`.
3. In Android Studio scegli **Open** e seleziona questa cartella.
4. Attendi la sincronizzazione Gradle e installa Android SDK Platform 35 se richiesto.
5. Per un APK di prova: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. L'APK di debug sarà normalmente in `app/build/outputs/apk/debug/app-debug.apk`.

Per distribuire l'app, genera un APK firmato da **Build > Generate Signed Bundle / APK**.
